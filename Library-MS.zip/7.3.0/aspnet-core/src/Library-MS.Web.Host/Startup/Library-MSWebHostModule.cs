﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Library-MS.Configuration;

namespace Library-MS.Web.Host.Startup
{
    [DependsOn(
       typeof(Library-MSWebCoreModule))]
    public class Library-MSWebHostModule: AbpModule
    {
        private readonly IWebHostEnvironment _env;
        private readonly IConfigurationRoot _appConfiguration;

        public Library-MSWebHostModule(IWebHostEnvironment env)
        {
            _env = env;
            _appConfiguration = env.GetAppConfiguration();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(Library-MSWebHostModule).GetAssembly());
        }
    }
}
