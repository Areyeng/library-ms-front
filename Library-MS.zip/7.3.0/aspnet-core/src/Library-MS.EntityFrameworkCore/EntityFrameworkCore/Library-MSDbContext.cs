﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using Library-MS.Authorization.Roles;
using Library-MS.Authorization.Users;
using Library-MS.MultiTenancy;

namespace Library-MS.EntityFrameworkCore
{
    public class Library-MSDbContext : AbpZeroDbContext<Tenant, Role, User, Library-MSDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public Library-MSDbContext(DbContextOptions<Library-MSDbContext> options)
            : base(options)
        {
        }
    }
}
