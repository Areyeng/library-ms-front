using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace Library-MS.EntityFrameworkCore
{
    public static class Library-MSDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<Library-MSDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<Library-MSDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
