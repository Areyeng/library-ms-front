﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Library-MS.Configuration;
using Library-MS.Web;

namespace Library-MS.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class Library-MSDbContextFactory : IDesignTimeDbContextFactory<Library-MSDbContext>
    {
        public Library-MSDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<Library-MSDbContext>();
            
            /*
             You can provide an environmentName parameter to the AppConfigurations.Get method. 
             In this case, AppConfigurations will try to read appsettings.{environmentName}.json.
             Use Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") method or from string[] args to get environment if necessary.
             https://docs.microsoft.com/en-us/ef/core/cli/dbcontext-creation?tabs=dotnet-core-cli#args
             */
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            Library-MSDbContextConfigurer.Configure(builder, configuration.GetConnectionString(Library-MSConsts.ConnectionStringName));

            return new Library-MSDbContext(builder.Options);
        }
    }
}
