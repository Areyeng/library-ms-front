﻿using Abp.Application.Services.Dto;

namespace Library-MS.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

