using System.ComponentModel.DataAnnotations;

namespace Library-MS.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}