﻿using System.Threading.Tasks;
using Abp.Application.Services;
using Library-MS.Sessions.Dto;

namespace Library-MS.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
