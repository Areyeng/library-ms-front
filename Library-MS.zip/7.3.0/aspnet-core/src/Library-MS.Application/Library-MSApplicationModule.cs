﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Library-MS.Authorization;

namespace Library-MS
{
    [DependsOn(
        typeof(Library-MSCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class Library-MSApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<Library-MSAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(Library-MSApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddMaps(thisAssembly)
            );
        }
    }
}
