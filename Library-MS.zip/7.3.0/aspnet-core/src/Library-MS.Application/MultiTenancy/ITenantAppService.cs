﻿using Abp.Application.Services;
using Library-MS.MultiTenancy.Dto;

namespace Library-MS.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

