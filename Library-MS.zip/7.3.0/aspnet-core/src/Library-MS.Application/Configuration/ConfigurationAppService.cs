﻿using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Runtime.Session;
using Library-MS.Configuration.Dto;

namespace Library-MS.Configuration
{
    [AbpAuthorize]
    public class ConfigurationAppService : Library-MSAppServiceBase, IConfigurationAppService
    {
        public async Task ChangeUiTheme(ChangeUiThemeInput input)
        {
            await SettingManager.ChangeSettingForUserAsync(AbpSession.ToUserIdentifier(), AppSettingNames.UiTheme, input.Theme);
        }
    }
}
