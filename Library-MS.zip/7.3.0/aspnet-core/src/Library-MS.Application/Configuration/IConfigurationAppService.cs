﻿using System.Threading.Tasks;
using Library-MS.Configuration.Dto;

namespace Library-MS.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
