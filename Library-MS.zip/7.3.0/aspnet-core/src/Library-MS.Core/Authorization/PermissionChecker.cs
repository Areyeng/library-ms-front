﻿using Abp.Authorization;
using Library-MS.Authorization.Roles;
using Library-MS.Authorization.Users;

namespace Library-MS.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
