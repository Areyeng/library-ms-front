﻿using Library-MS.Debugging;

namespace Library-MS
{
    public class Library-MSConsts
    {
        public const string LocalizationSourceName = "Library-MS";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;


        /// <summary>
        /// Default pass phrase for SimpleStringCipher decrypt/encrypt operations
        /// </summary>
        public static readonly string DefaultPassPhrase =
            DebugHelper.IsDebug ? "gsKxGZ012HLL3MI5" : "4cab127a7eb84470b2746c1d26470aa5";
    }
}
