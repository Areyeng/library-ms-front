﻿using Abp.AspNetCore;
using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Library-MS.EntityFrameworkCore;
using Library-MS.Web.Startup;
using Microsoft.AspNetCore.Mvc.ApplicationParts;

namespace Library-MS.Web.Tests
{
    [DependsOn(
        typeof(Library-MSWebMvcModule),
        typeof(AbpAspNetCoreTestBaseModule)
    )]
    public class Library-MSWebTestModule : AbpModule
    {
        public Library-MSWebTestModule(Library-MSEntityFrameworkModule abpProjectNameEntityFrameworkModule)
        {
            abpProjectNameEntityFrameworkModule.SkipDbContextRegistration = true;
        } 
        
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(Library-MSWebTestModule).GetAssembly());
        }
        
        public override void PostInitialize()
        {
            IocManager.Resolve<ApplicationPartManager>()
                .AddApplicationPartsIfNotAddedBefore(typeof(Library-MSWebMvcModule).Assembly);
        }
    }
}