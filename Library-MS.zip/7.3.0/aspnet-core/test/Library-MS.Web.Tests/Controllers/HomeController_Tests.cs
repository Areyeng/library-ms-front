﻿using System.Threading.Tasks;
using Library-MS.Models.TokenAuth;
using Library-MS.Web.Controllers;
using Shouldly;
using Xunit;

namespace Library-MS.Web.Tests.Controllers
{
    public class HomeController_Tests: Library-MSWebTestBase
    {
        [Fact]
        public async Task Index_Test()
        {
            await AuthenticateAsync(null, new AuthenticateModel
            {
                UserNameOrEmailAddress = "admin",
                Password = "123qwe"
            });

            //Act
            var response = await GetResponseAsStringAsync(
                GetUrl<HomeController>(nameof(HomeController.Index))
            );

            //Assert
            response.ShouldNotBeNullOrEmpty();
        }
    }
}