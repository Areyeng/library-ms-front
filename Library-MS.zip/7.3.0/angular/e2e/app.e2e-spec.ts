import { Library-MSTemplatePage } from './app.po';

describe('Library-MS App', function() {
  let page: Library-MSTemplatePage;

  beforeEach(() => {
    page = new Library-MSTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
